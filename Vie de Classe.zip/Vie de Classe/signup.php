<header>
<?php
	require "header.php";
?>
</header>

	<main>
		

		<?php 
			if (isset($_GET['error'])) {
				if ($_GET['error'] == "emptyfields") {
					echo "<p> Remplissez tous les champs.</p>";
				}
				else if ($_GET['error'] == "invaliduidmail") {
					echo "<p> Username et email incorrects.</p>";
				}
				else if ($_GET['error'] == "invaliduid") {
					echo "<p> Username incorrect</p>";
				}
				else if ($_GET['error'] == "invalidmail") {
					echo "<p> Email incorrect.</p>";
				}
				else if ($_GET['error'] == "passwordcheck") {
					echo "<p> Les mots de passe ne sont pas identiques.</p>";
				}
				else if ($_GET['error'] == "usertaken") {
					echo "<p> L'username est déja attribué.</p>";
				}
			}

			else if (isset($_GET['signup']) == "success") {
				echo "<p> Compte crée avec succès!</p>";
			}

		 ?>
<body>
	<div style="margin: auto; width: 30%; text-align : center;">
		<h2>Inscription</h2>
		<form action="includes/signup.inc.php" method="post" enctype="multipart/form-data">
  			<div class="form-group">
    			<h4><label for="userId">Username:</label></h4>
    			<input type="text" class="form-control" name="uid" placeholder="ex : Vegeta58">
  			</div>
  			<div class="form-group">
    			<h4><label for="email">Adresse E-mail:</label></h4>
    			<input type="email" class="form-control" name="mail" placeholder="ex: azert@abcde.fr">
  			</div>
  			<div class="form-group">
    			<h4><label for="pwd">Mot de Passe:</label></h4>
    			<input type="password" class="form-control" name="pwd">
  			</div>
  			<div class="form-group">
    			<h4><label for="pwd-repeat"> Confirmer Mot De Passe:</label></h4>
    			<input type="password" class="form-control" name="pwd-repeat" id="pwd-repeat">
  			</div>
  			<button type="submit" class="btn btn-primary btn-block" name="btn-signup" id="btn">Confirmer</button>
		</form>
	</div>
		</body>	
	</main>
<footer>
<?php
	require "footer.php";
?>
</footer>