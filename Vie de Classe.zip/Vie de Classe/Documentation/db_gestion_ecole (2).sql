-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  sam. 25 mai 2019 à 04:41
-- Version du serveur :  5.7.24
-- Version de PHP :  7.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `db_gestion_ecole`
--

-- --------------------------------------------------------

--
-- Structure de la table `posts`
--

DROP TABLE IF EXISTS `posts`;
CREATE TABLE IF NOT EXISTS `posts` (
  `id_message` int(11) NOT NULL AUTO_INCREMENT,
  `message` text NOT NULL,
  `Date_pub` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `published` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_message`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `posts`
--

INSERT INTO `posts` (`id_message`, `message`, `Date_pub`, `published`) VALUES
(1, 'Bonjour, bienvenue sur le site Web de la classe!', '2019-04-18 17:23:36', 1),
(9, 'Monsieur DUPONT sera absent aujourd\'hui.', '2019-05-23 19:58:26', 1);

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id_Users` int(11) NOT NULL AUTO_INCREMENT,
  `uid_Users` varchar(50) NOT NULL,
  `email_Users` varchar(50) NOT NULL,
  `pwd_Users` varchar(255) NOT NULL,
  PRIMARY KEY (`id_Users`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id_Users`, `uid_Users`, `email_Users`, `pwd_Users`) VALUES
(5, 'lulu', 'jodj@gmail.com', '$2y$10$aisNCAzNhumaYstYZK/OkufRGhbajkHe.fXSkDDUo3uoHbmAEaoTW'),
(4, 'samuel', 'samuel@gmail.com', '$2y$10$gF88XIkfXpDYUKfRRuiih.jIEbSZzQQ2gnkGwceOkouAXhfF5xQhm'),
(6, 'manon', 'manon@gmail.com', '$2y$10$2nQK1PNetaIiHeid7xjWjesCWAAuVsXJxRLeMoMpHZKV9wR8mFXuS'),
(7, 'frantzia', 'frantzia@gmail.com', '$2y$10$Wo.uvxOHJ2ruZ81pfUDXaOCzHvxWnTFi5OYDzOcVxA/mN8McfkaTG');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
