<?php require_once( 'includes/public_fonction.php') ?>

<?php $posts = getPublishedPosts(); ?>


<body>
	<main>

		<h3>Hello Student!</h3>


  <hr>


  <?php 
  foreach ($posts as $post){
    echo'
      <h6><div class = "post_info">
        <div class="info">
          <span>'.date("F j, Y ", strtotime($post["Date_pub"])).'</span>
        </div>
      </div></h6>
    <div class="post" style="margin-left: 0px;">'
      .$post['message'].'
    </div>
    <br>';
  }
  ?>


	</main>
	</body>
