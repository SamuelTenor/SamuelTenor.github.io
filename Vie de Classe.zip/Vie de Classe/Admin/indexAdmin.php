<?php require_once( 'includes/public_fonction.php') ?>

<?php $posts = getPublishedPosts(); ?>


<body>
	<main>

		<h3>Hello Admin!</h3>

    	<div >
			<form action="Admin/includes/status.inc.php" method="post">
  			<div class="form-group">
    			<textarea name="message" rows="2" cols="100" placeholder=" Entrez le message.">
    			</textarea>
    			<div style="margin: auto; width: 30%; text-align: right;">
  					<button type="submit" class="btn btn-primary btn-block" name="btn-post">Confirmer</button>
  				</div>
  			</div>
			</form>
	   </div>

  <hr>


  <?php foreach ($posts as $post){
    echo'
      <h6><u><div class = "post_info">
        <div class="info">
          <span>'.date("F j, Y ", strtotime($post["Date_pub"])).'</span>
        </div>
      </div></u></h6>
    <div class="post" style="margin-left: 0px;">'
      .$post['message'].'
    </div>
    <br>';
  }
  ?>


	</main>
	</body>


