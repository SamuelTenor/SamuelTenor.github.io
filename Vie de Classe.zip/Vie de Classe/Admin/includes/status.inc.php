<?php

#script de la création de compte

if (isset($_POST["btn-post"])) {
 	
 	require "../../includes/dbh.inc.php";

 	$message =$_POST["message"];


 	# Vérification des champs 
 	if (empty($message)) {
 		header("Location: ../../index.php?error=emptyfields");
 		exit();

 	}

 	else {

		$sql ="INSERT INTO posts(message) VALUES (?)";
 		$stmt = mysqli_stmt_init($conn);

 		if (!mysqli_stmt_prepare($stmt, $sql)) {
 		header("Location: ../../index.php?error=sqlerror");
 		exit();
 		}

 		else{

 			mysqli_stmt_bind_param($stmt, "s", $message );
 			mysqli_stmt_execute($stmt);
 			mysqli_stmt_store_result($stmt);
 			header("Location: ../../index.php?postSuccess");
 			exit();
 		}
 	}
 }

 # fermeture de la base de données
 mysqli_stmt_close($stmt);
 mysqli_close($conn);