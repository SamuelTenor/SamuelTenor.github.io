<?php

include('dbh.inc.php');

/* Récupérer tous les posts*/
function getPublishedPosts(){

	global $conn;
	$sql= "SELECT * FROM posts WHERE published=true";
	$result = mysqli_query($conn, $sql);

	/* Récupére les posts dans un tableau associatif appelé posts*/
	$posts = mysqli_fetch_all($result, MYSQLI_ASSOC);

	return $posts;
}

?>