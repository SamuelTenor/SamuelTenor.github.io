<!DOCTYPE html>
<html>
	<header>
		<?php
			require "header.php";
		?>
		
	</header>
	<body>
		<main>
			<div style="margin: auto; text-align: center;"  >
				<h4>EMPLOI DU TEMPS</h4>
				<br>
			</div>

			<table>
				<tr>
					<td>
						<iframe src="Admin/uploads/edt.pdf" width="1000" height="600" align="center"></iframe>
					</td>
				</tr>
			</table>		
		</main>
	</body>

		<footer>
			<?php
				require "footer.php";
			?>
		</footer>
</html>

